SURF HACK — projeto Android demonstrativo

O QUE ESTE PROJETO FAZ
- Cria um botão flutuante "SH".
- Permite arrastar o botão pela tela.
- Abre/fecha um painel azul e roxo.
- Mostra interruptores demonstrativos.

O QUE NÃO FAZ
- Não altera o Subway Surfers original.
- Não injeta código no jogo.
- Não modifica moedas, chaves, pontuação, velocidade, colisões ou proteções.
Os interruptores são apenas visuais.

COMO GERAR O APK
1. Extraia a pasta SURF_HACK_Android_Project.
2. Abra a pasta em Android Studio (em um computador) ou em um ambiente Android compatível com projetos Gradle.
3. Aguarde a sincronização do Gradle.
4. Escolha Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O APK de depuração normalmente aparece em app/build/outputs/apk/debug/app-debug.apk.
6. Instale o APK no seu Android. Se o sistema pedir, autorize a instalação dessa fonte.

PERMISSÃO DO BOTÃO FLUTUANTE
Na primeira abertura, toque em "ATIVAR BOTÃO FLUTUANTE" e permita "Exibir sobre outros apps" para SURF HACK.

REQUISITOS
- Android Studio recente
- JDK 17
- Android SDK 35
- Gradle compatível com Android Gradle Plugin 8.6.1

OBSERVAÇÃO
Este pacote contém o código-fonte, não um APK compilado. Não abra APKs de origem desconhecida.
