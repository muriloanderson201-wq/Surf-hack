package com.surf.hack

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Button

class FloatingMenuService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (bubble == null) createBubble()
        return START_NOT_STICKY
    }

    private fun params(width: Int, height: Int): WindowManager.LayoutParams {
        return WindowManager.LayoutParams(
            width, height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 180 }
    }

    private fun createBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val b = TextView(this).apply {
            text = "SH"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(105, 75, 220))
            setPadding(18, 14, 18, 14)
            setOnClickListener { togglePanel() }
            setOnTouchListener(DragTouchListener())
        }
        bubble = b
        wm.addView(b, params(WRAP, WRAP))
    }

    private fun togglePanel() {
        if (panel != null) {
            wm.removeView(panel)
            panel = null
            return
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 18)
            setBackgroundColor(Color.rgb(19, 24, 58))
        }
        val heading = TextView(this).apply {
            text = "SURF HACK  •  DEMO"
            textSize = 18f
            setTextColor(Color.rgb(140, 120, 255))
            setPadding(0, 0, 0, 12)
        }
        box.addView(heading)
        val labels = listOf(
            "Speed Hack (visual)", "Coin Magnet (visual)", "Infinite Jump (visual)",
            "Hoverboard (visual)", "No Collision (visual)", "Score Multiplier (visual)"
        )
        labels.forEach { label ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val name = TextView(this).apply {
                text = label
                textSize = 14f
                setTextColor(Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
                setPadding(0, 8, 12, 8)
            }
            val toggle = Button(this).apply {
                text = "OFF"
                setOnClickListener { text = if (text == "OFF") "ON" else "OFF" }
            }
            row.addView(name)
            row.addView(toggle)
            box.addView(row)
        }
        val close = Button(this).apply {
            text = "FECHAR MENU"
            setOnClickListener { togglePanel() }
        }
        box.addView(close)
        panel = box
        wm.addView(box, params(WRAP, WRAP).apply { x = 80; y = 250 })
    }

    private inner class DragTouchListener : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        private var moved = false
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            val lp = v.layoutParams as WindowManager.LayoutParams
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = lp.x; startY = lp.y; moved = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > 8) moved = true
                    lp.x = startX + dx; lp.y = startY + dy
                    wm.updateViewLayout(v, lp)
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) v.performClick()
                    return true
                }
            }
            return false
        }
    }

    override fun onDestroy() {
        bubble?.let { if (it.isAttachedToWindow) wm.removeView(it) }
        panel?.let { if (it.isAttachedToWindow) wm.removeView(it) }
        bubble = null; panel = null
        super.onDestroy()
    }

    companion object { private const val WRAP = WindowManager.LayoutParams.WRAP_CONTENT }
}
