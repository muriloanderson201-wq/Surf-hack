package com.surf.hack

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(Color.rgb(13, 17, 42))
        }
        val title = TextView(this).apply {
            text = "SURF HACK"
            textSize = 30f
            setTextColor(Color.rgb(153, 125, 255))
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "PAINEL FLUTUANTE • DEMONSTRAÇÃO"
            textSize = 12f
            setTextColor(Color.rgb(93, 220, 255))
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 28)
        }
        val button = Button(this).apply {
            text = "ATIVAR BOTÃO FLUTUANTE"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                } else {
                    startService(Intent(this@MainActivity, FloatingMenuService::class.java))
                    finish()
                }
            }
        }
        val note = TextView(this).apply {
            text = "Este app cria apenas um painel visual. Os controles não modificam moedas, pontuação, velocidade ou proteções do Subway Surfers."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(button)
        root.addView(note)
        setContentView(root)
    }
}
